package com.example.astro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
