abstract class BlocEvent {
  const BlocEvent();
}
