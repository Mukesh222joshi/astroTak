class AppRoutes
{
  static const String profile = "/profile";
}